from django.urls import path
from .import views

urlpatterns=[
    path('',views.register,name='register'),
    path('getregist',views.rdisplay,name='rdisplay'),
    path('updater/<int:id>',views.rupdate,name='rupdate'),
    path('deleter/<int:id>/',views.rdelete, name='rdelete'),
]
