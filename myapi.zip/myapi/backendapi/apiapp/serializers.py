from rest_framework import serializers
from .models import registration

class registrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = registration
        fields = '__all__'