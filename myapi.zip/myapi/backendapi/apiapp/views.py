from django.shortcuts import render
from .models import registration
from .serializers import registrationSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
# Create your views here.


@api_view(['POST'])
def register(request):
    if request.method=='POST':
        serializer=registrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg':'saved successfully','data':serializer.data})
        
@api_view(['GET'])
def rdisplay(request):
    if request.method=='GET':
        data=registration.objects.all()
        serializer=registrationSerializer(data,many=True,context={'request':request})
        return Response(serializer.data)
    

    
@api_view(['PUT'])
def rupdate(request,id):
    try:
        instance=registration.objects.get(id=id)
    except registration.DoesNotExist:
        return Response({"error":"Not found"},status=status.HTTP_404_NOT_FOUND)
    
    if request.method=='PUT':
        serializer=registrationSerializer(instance,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['DELETE'])
def rdelete(request,id):
    try:
        instance=registration.objects.get(id=id)
    except registration.DoesNotExist:
        return Response({"error":"Not found"},status=status.HTTP_404_NOT_FOUND)

    if request.method=='DELETE':
        instance.delete()
        return Response({"data":"deleted"})



